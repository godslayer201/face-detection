import cv2
import time
v=cv2.VideoCapture(0)
time.sleep(2)
fdc=cv2.CascadeClassifier(r'C:\Users\Hp\AppData\Local\Programs\Python\Python36\Lib\site-packages\cv2\data\haarcascade_frontalface_alt.xml')
while(1):
      d,i=v.read()
      print(i.shape)
      face=fdc.detectMultiScale(i,1.3,9)
      print(face)
      if(len(face)>=1):
         for x,y,w,h in face:
           cv2.rectangle(i,(x,y),(x+w,y+h),(0,0,255),2)
      
      cv2.imshow('image',i)
      k=cv2.waitKey(5)
      if(k==ord('a')):
         cv2.destroyAllWindows()
         break

